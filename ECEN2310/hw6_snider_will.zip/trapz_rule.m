function [t,X] = trapz_rule(A,X0,dT,T)
%not sure if this one works, figure seems off,
% inputs: A, X0, dT, T
% outputs: t, x
[n,m]=size(A);
if n~=m
    error('A should be a square matrix.');
end
[n2,m2]=size(X0);
if n2~=n || m2~=1
    error('X0 should be a column vector with the same number of rows as A')
end
if ~isscalar(dT)
    error('dT should be a scalar')
end
if ~isscalar(T)
    error('T should be a scalar')
end
N=T/dT;
if floor(N)~=N
    warning('found N = %d, changed to integer %d',N,floor(N))
    N=floor(N);
end
t=0:dT:N*dT;
I=eye(n);
K0=eye(N+1);
K1=diag(ones(1,N),-1);
D=kron(K0^2,I*A/dT)-kron(K1^2,I*A/dT);
e=[X0;zeros(size(D,1)- size(X0,1),1)];
X=reshape(D\e,[size(X0,1),N+1]);
plot(t,X(1,:));
end

