clc
close all
clear variables

syms C omega t y0
syms y(t)
A = [0 1
    -1 -1];
X0 = [10 
    0];
dy = diff(y,t);
ddy = diff(dy,t);
myode = ddy+C*omega*dy+(omega^2)*y;

mycond=[y(0)==y0,dy(0)==0];
mysol(t) = dsolve(myode,mycond);
figure(1);
fplot(subs(mysol,[C omega y0],[0.5 1 10]), [0 20]);
hold on
f_eular(A,X0,.01,20);
f_eular(A,X0,.1,20);
f_eular(A,X0,.5,20);
f_eular(A,X0,1,20);
legend("analytic solution","eular: dT=.01","eular: dT=.1","eular: dT= .5","eular: dT = 1");
% at dT = 2+ the graph is completely off
figure(2)
fplot(subs(mysol,[C omega y0],[0.5 1 10]), [0 20]);
hold on
b_eular(A,X0,.01,20);
b_eular(A,X0,.1,20);
b_eular(A,X0,.5,20);
b_eular(A,X0,1,20);
legend("analytic solution","eular: dT=.01","eular: dT=.1","eular: dT= .5","eular: dT = 1");
figure(3)
fplot(subs(mysol,[C omega y0],[0.5 1 10]), [0 20]);
hold on
trapz_rule(A,X0,.01,20);
trapz_rule(A,X0,.1,20);
trapz_rule(A,X0,.5,20); 
trapz_rule(A,X0,1,20);
legend("analytic solution","trapz: dT=.01","trapz: dT=.1","trapz: dT= .5","trapz: dT = 1");
hold off
figure(4)
subplot(2,1,1)
hold on
fplot(subs(mysol,[C omega y0],[0.5 1 10]), [0 20]);
f_eular(A,X0,.2,20);
b_eular(A,X0,.2,20);
% trapz_rule(A,X0,.2,20); didnt include because it's wrong
title('Y');
subplot(2,1,2)
fplot(diff(subs(mysol,[C omega y0],[0.5 1 10])), [0 20]);
% don't know how to get the derivatives from the approximations




