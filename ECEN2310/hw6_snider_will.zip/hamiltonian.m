function H = hamiltonian(fR, al, N)
% function to generate a hamiltonian matrix
% inputs: fR=recoil frequency, al = normalized lattice depth, 
% N=momenum states
% outputs: H = hamiltonian matrix
n = 2*N+1;
H = diag(n);
diagH = 4*(-N:N).^2;
for i=1:n
    H(i,i) = diagH(i);
    if i<n
        H(i+1,i)=-al;
        H(i,i+1)=-al;
    end
end
H = fR.*H;
end

