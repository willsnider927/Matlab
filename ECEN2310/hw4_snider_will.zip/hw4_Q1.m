clc
close all
clear variables

% 1.
a = 0:5:100;
disp(a([7 8 15 16]));
disp(a(1:5));
disp(flip(a(1:5)));
disp(a(end-5:end));
disp(flip(a(end-5:end)));
disp(a(find(a<42)));
disp(a(a<42));



