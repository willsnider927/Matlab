clc 
close all
clear variables

q = linspace(0,500,100);
P = 120 - (3*(10^-4)*q.^2);
N = 7*(10^-4)*q.^2;

figure(1);
hold on;
plot(N);
plot(P);

e = abs(P - N);
plot(find(e==min(e)),N(e==min(e)),'k*')
% not directly over point

j = find(e==min(e));
q_2 = linspace(q(j-1),q(j+1),200);

P_2 = 120 - (3*(10^-4)*q_2.^2);
N_2 = 7*(10^-4)*q_2.^2;
figure(2);
hold on;
plot(N_2);
plot(P_2);
e = abs(P_2 - N_2);
plot(find(e==min(e)),N_2(e==min(e)),'kx')
