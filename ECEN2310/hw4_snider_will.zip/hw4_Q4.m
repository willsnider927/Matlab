clc
close all
clear variables

x = linspace(-1,1,100);
k=4;
f = exp(-k*x.^2);
g = diff(f);
figure(1);
hold on;
plot(x(1:length(x)-1),g);
x_1 = g == min(g);
x_2 = g == max(g);
plot(x(x_1),g(x_1),'r*');
plot(x(x_2),g(x_2),'r*');